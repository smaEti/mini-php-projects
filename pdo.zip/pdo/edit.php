<?php

try{
    $connection = new PDO("mysql:host=localhost;dbname=kelas", 'root', '');
    $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // TODO = اینجا قرار بود اینکارو بکنم
    $query = $connection->prepare(
        "SELECT * FROM users where id = :id"
    );
    $query->bindValue(':id', $_GET['id']);

    $query->execute();
    $user = $query->fetch(PDO::FETCH_ASSOC);

    if($user === false){
        // set session error : کاربر یافت نشد
        header('Location: 404.php');
        die();
    }

}catch(PDOException $e){
    echo 'با مدیریت تماس بگیرید';
    echo $e->getMessage();
}

?>

    <!-- تمرین : ویرایش شود -->
    <div>
        <label>نام :</label>
        <label><?php echo $user['name'] ?></label>
    </div>
    <div>
        <label>نام کاربری :</label>
        <label><?php echo $user['username'] ?></label>
    </div>
